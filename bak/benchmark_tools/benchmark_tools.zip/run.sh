python benchmark_parallel.py --backend openai \
      	--host 0.0.0.0 \
	--port 9999 \
	--tokenizer /work/model/Qwen2___5-0___5B-Instruct  \
	--epochs 2 \
	--parallel-num 8  \
	--prompt-tokens 2048  \
	--output-tokens 1000 \
	--served-model-name qwen \
	--api-key '123456' \
	--benchmark-csv benchmark_parallel.csv

